package com.example.TorneoBadminton;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TorneoBadmintonApplication {

	public static void main(String[] args) {
		SpringApplication.run(TorneoBadmintonApplication.class, args);
	}

}
