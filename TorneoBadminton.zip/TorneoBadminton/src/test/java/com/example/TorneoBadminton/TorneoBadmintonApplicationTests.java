package com.example.TorneoBadminton;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TorneoBadmintonApplicationTests {

	@Test
	void contextLoads() {
	}

}
